## Packages
recharts | Data visualization for player stats, finances, and match analytics
framer-motion | Smooth animations for page transitions and interactive elements
date-fns | Formatting dates for matches and contracts
clsx | Utility for constructing className strings conditionally
tailwind-merge | Utility for merging Tailwind classes safely

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  display: ["var(--font-display)"],
  body: ["var(--font-body)"],
  mono: ["var(--font-mono)"],
}

Tailwind Config - extend colors:
colors: {
  pitch: {
    DEFAULT: "hsl(var(--pitch))",
    foreground: "hsl(var(--pitch-foreground))",
  },
}

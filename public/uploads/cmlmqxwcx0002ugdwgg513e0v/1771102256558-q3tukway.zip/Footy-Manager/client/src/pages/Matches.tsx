import { useMatches } from "@/hooks/use-matches";
import { MatchCard } from "@/components/MatchCard";
import { format } from "date-fns";

export default function Matches() {
  const { data: matches, isLoading } = useMatches();

  const groupedMatches = matches?.reduce((groups, match) => {
    const month = format(new Date(match.date), "MMMM yyyy");
    if (!groups[month]) groups[month] = [];
    groups[month].push(match);
    return groups;
  }, {} as Record<string, typeof matches>);

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <div>
        <h1 className="text-3xl font-display text-white">Match Center</h1>
        <p className="text-muted-foreground">Fixtures, results and live updates.</p>
      </div>

      {isLoading ? (
        <div className="space-y-4">
             {[1,2,3].map(i => <div key={i} className="h-24 bg-card/30 rounded-xl animate-pulse" />)}
        </div>
      ) : (
        <div className="space-y-8">
            {Object.entries(groupedMatches || {}).map(([month, monthMatches]) => (
                <div key={month} className="space-y-4">
                    <h3 className="text-lg font-bold text-primary sticky top-0 bg-background/80 backdrop-blur py-2 z-10">{month}</h3>
                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                        {monthMatches.map(match => (
                            <MatchCard key={match.id} match={match} />
                        ))}
                    </div>
                </div>
            ))}
        </div>
      )}
    </div>
  );
}

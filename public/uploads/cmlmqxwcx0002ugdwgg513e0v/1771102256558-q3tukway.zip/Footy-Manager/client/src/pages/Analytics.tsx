import { usePlayers } from "@/hooks/use-players";
import { useMatches } from "@/hooks/use-matches";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from "recharts";
import { BarChart3, PieChart as PieChartIcon, Activity, TrendingUp } from "lucide-react";

export default function Analytics() {
  const { data: players } = usePlayers();
  const { data: matches } = useMatches();

  const positionData = [
    { name: 'GK', value: players?.filter(p => p.position === 'GK').length || 0 },
    { name: 'DEF', value: players?.filter(p => p.position === 'DEF').length || 0 },
    { name: 'MID', value: players?.filter(p => p.position === 'MID').length || 0 },
    { name: 'FWD', value: players?.filter(p => p.position === 'FWD').length || 0 },
  ];

  const ratingData = players?.map(p => ({
    name: p.name.split(' ').pop(),
    rating: parseFloat(p.averageRating || "0")
  })).sort((a, b) => b.rating - a.rating).slice(0, 6) || [];

  const COLORS = ['#3b82f6', '#10b981', '#f59e0b', '#ef4444'];

  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      <div>
        <h1 className="text-3xl font-display text-white">Advanced Analytics</h1>
        <p className="text-muted-foreground">Deep dive into team and player performance metrics.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center gap-2">
            <Activity className="w-5 h-5 text-primary" />
            <CardTitle>Top Rated Players</CardTitle>
          </CardHeader>
          <CardContent className="h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={ratingData}>
                <XAxis dataKey="name" stroke="#64748b" fontSize={12} />
                <YAxis stroke="#64748b" fontSize={12} domain={[0, 10]} />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#1a202c', border: 'none', borderRadius: '8px' }}
                  itemStyle={{ color: '#fff' }}
                />
                <Bar dataKey="rating" fill="var(--primary)" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center gap-2">
            <PieChartIcon className="w-5 h-5 text-primary" />
            <CardTitle>Squad Distribution</CardTitle>
          </CardHeader>
          <CardContent className="h-[300px] flex items-center">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={positionData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={80}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {positionData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip 
                  contentStyle={{ backgroundColor: '#1a202c', border: 'none', borderRadius: '8px' }}
                  itemStyle={{ color: '#fff' }}
                />
              </PieChart>
            </ResponsiveContainer>
            <div className="space-y-2 pr-8">
              {positionData.map((pos, i) => (
                <div key={pos.name} className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full" style={{ backgroundColor: COLORS[i] }} />
                  <span className="text-xs text-muted-foreground">{pos.name}: {pos.value}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="bg-secondary/20">
          <CardContent className="pt-6 text-center">
            <TrendingUp className="w-8 h-8 text-primary mx-auto mb-2" />
            <h4 className="text-2xl font-bold text-white">72%</h4>
            <p className="text-xs text-muted-foreground uppercase tracking-wider">Pass Accuracy</p>
          </CardContent>
        </Card>
        <Card className="bg-secondary/20">
          <CardContent className="pt-6 text-center">
            <Activity className="w-8 h-8 text-green-500 mx-auto mb-2" />
            <h4 className="text-2xl font-bold text-white">1.8</h4>
            <p className="text-xs text-muted-foreground uppercase tracking-wider">Goals Per Game</p>
          </CardContent>
        </Card>
        <Card className="bg-secondary/20">
          <CardContent className="pt-6 text-center">
            <BarChart3 className="w-8 h-8 text-blue-500 mx-auto mb-2" />
            <h4 className="text-2xl font-bold text-white">54.2%</h4>
            <p className="text-xs text-muted-foreground uppercase tracking-wider">Avg. Possession</p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

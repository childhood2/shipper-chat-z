import { usePlayers } from "@/hooks/use-players";
import { useMatches } from "@/hooks/use-matches";
import { useFinances } from "@/hooks/use-finances";
import { StatCard } from "@/components/StatCard";
import { MatchCard } from "@/components/MatchCard";
import { LineupBuilder } from "@/components/LineupBuilder";
import { Users, DollarSign, Trophy, Activity, ArrowRight } from "lucide-react";
import { Link } from "wouter";
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer } from "recharts";

export default function Dashboard() {
  const { data: players, isLoading: playersLoading } = usePlayers();
  const { data: matches, isLoading: matchesLoading } = useMatches();
  const { data: finances, isLoading: financesLoading } = useFinances();

  const totalValue = players?.reduce((acc, p) => acc + p.marketValue, 0) || 0;
  const squadSize = players?.length || 0;
  const nextMatch = matches?.find(m => m.status === "Scheduled");
  
  // Mock performance data
  const data = [
    { name: 'GW1', rating: 6.8 },
    { name: 'GW2', rating: 7.2 },
    { name: 'GW3', rating: 6.5 },
    { name: 'GW4', rating: 7.5 },
    { name: 'GW5', rating: 7.8 },
  ];

  if (playersLoading || matchesLoading) {
    return <div className="p-8 text-primary animate-pulse">Initializing Dashboard System...</div>;
  }

  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-display text-white">Manager Overview</h1>
          <p className="text-muted-foreground">Welcome back, Boss. Here's your daily briefing.</p>
        </div>
        <div className="flex gap-3">
             <button className="px-4 py-2 bg-secondary text-white rounded-lg border border-white/10 hover:bg-white/5 transition-colors text-sm font-medium">Download Report</button>
             <Link href="/squad" className="px-4 py-2 bg-primary text-primary-foreground rounded-lg shadow-lg shadow-primary/25 hover:bg-primary/90 transition-all text-sm font-bold flex items-center gap-2">
                Manage Squad <ArrowRight className="w-4 h-4" />
             </Link>
        </div>
      </div>

      {/* KPI Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard 
            title="Squad Market Value" 
            value={`$${(totalValue / 1000000).toFixed(1)}M`} 
            icon={<DollarSign className="w-6 h-6" />}
            trend="up"
            trendValue="+2.4%"
        />
        <StatCard 
            title="Active Players" 
            value={squadSize} 
            icon={<Users className="w-6 h-6" />}
            description="3 Injured, 1 Suspended"
        />
        <StatCard 
            title="League Position" 
            value="2nd" 
            icon={<Trophy className="w-6 h-6" />}
            trend="neutral"
            trendValue="-"
        />
        <StatCard 
            title="Avg. Form" 
            value="7.2" 
            icon={<Activity className="w-6 h-6" />}
            trend="up"
            trendValue="+0.3"
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 h-[500px]">
        {/* Next Match & Schedule */}
        <div className="lg:col-span-1 space-y-6 flex flex-col">
            <div className="flex items-center justify-between mb-2">
                <h3 className="font-bold text-lg text-white">Upcoming Fixtures</h3>
                <Link href="/matches" className="text-xs text-primary hover:underline">View All</Link>
            </div>
            {nextMatch ? (
                <MatchCard match={nextMatch} />
            ) : (
                <div className="glass-card p-6 text-center text-muted-foreground">No upcoming matches</div>
            )}
            
            <div className="glass-card p-6 flex-1 flex flex-col">
                <h3 className="font-bold text-sm text-muted-foreground uppercase mb-4">Team Performance</h3>
                <div className="flex-1 w-full min-h-[200px]">
                    <ResponsiveContainer width="100%" height="100%">
                        <LineChart data={data}>
                            <Tooltip 
                                contentStyle={{ backgroundColor: '#1a202c', border: 'none', borderRadius: '8px' }}
                                itemStyle={{ color: '#fff' }}
                            />
                            <Line 
                                type="monotone" 
                                dataKey="rating" 
                                stroke="var(--primary)" 
                                strokeWidth={3} 
                                dot={{ fill: 'var(--primary)', strokeWidth: 2 }}
                            />
                        </LineChart>
                    </ResponsiveContainer>
                </div>
            </div>
        </div>

        {/* Pitch View */}
        <div className="lg:col-span-2">
            <LineupBuilder />
        </div>
      </div>
    </div>
  );
}

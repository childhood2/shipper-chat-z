import { Link } from "wouter";
import { AlertTriangle } from "lucide-react";

export default function NotFound() {
  return (
    <div className="min-h-screen w-full flex flex-col items-center justify-center bg-background p-4 text-center">
      <div className="w-24 h-24 rounded-full bg-destructive/10 flex items-center justify-center mb-6 animate-pulse">
        <AlertTriangle className="w-12 h-12 text-destructive" />
      </div>
      <h1 className="text-6xl font-display font-bold text-white mb-2">404</h1>
      <h2 className="text-xl text-muted-foreground mb-8">Offside! Page not found.</h2>
      <Link href="/" className="px-8 py-3 bg-primary text-primary-foreground font-bold rounded-lg hover:bg-primary/90 transition-all">
        Return to Pitch
      </Link>
    </div>
  );
}

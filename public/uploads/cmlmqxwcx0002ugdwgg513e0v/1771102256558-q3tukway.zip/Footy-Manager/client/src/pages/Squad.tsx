import { useState } from "react";
import { usePlayers, useCreatePlayer } from "@/hooks/use-players";
import { PlayerCard } from "@/components/PlayerCard";
import { Plus, Search, Filter } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { insertPlayerSchema, type InsertPlayer } from "@shared/schema";
import { z } from "zod";

// Extend schema for form validation
const formSchema = insertPlayerSchema.extend({
  marketValue: z.coerce.number().min(0, "Must be positive"),
  wage: z.coerce.number().min(0, "Must be positive"),
  jerseyNumber: z.coerce.number().min(1, "Must be positive"),
  age: z.coerce.number().min(15, "Too young"),
});

export default function Squad() {
  const { data: players, isLoading } = usePlayers();
  const { mutateAsync: createPlayer } = useCreatePlayer();
  const [search, setSearch] = useState("");
  const [positionFilter, setPositionFilter] = useState("ALL");
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const { toast } = useToast();

  const form = useForm<InsertPlayer>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: "",
      position: "MID",
      jerseyNumber: 0,
      nationality: "",
      age: 20,
      marketValue: 1000000,
      wage: 5000,
      status: "Fit",
      contractExpires: new Date().toISOString().split('T')[0],
      appearances: 0,
      goals: 0,
      assists: 0,
      averageRating: "6.0"
    }
  });

  const onSubmit = async (data: InsertPlayer) => {
    try {
      await createPlayer(data);
      setIsCreateOpen(false);
      form.reset();
      toast({ title: "Player Signed", description: `${data.name} added to squad.` });
    } catch (error) {
      toast({ title: "Error", description: "Failed to create player", variant: "destructive" });
    }
  };

  const filteredPlayers = players?.filter(p => {
    const matchesSearch = p.name.toLowerCase().includes(search.toLowerCase());
    const matchesPos = positionFilter === "ALL" || p.position.includes(positionFilter);
    return matchesSearch && matchesPos;
  });

  const goalkeepers = filteredPlayers?.filter(p => p.position.includes("GK")) || [];
  const defenders = filteredPlayers?.filter(p => p.position.includes("DEF")) || [];
  const midfielders = filteredPlayers?.filter(p => p.position.includes("MID")) || [];
  const forwards = filteredPlayers?.filter(p => p.position.includes("FWD")) || [];

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-3xl font-display text-white">First Team Squad</h1>
          <p className="text-muted-foreground">Manage your roster, contracts and player development.</p>
        </div>
        
        <Dialog open={isCreateOpen} onOpenChange={setIsCreateOpen}>
          <DialogTrigger asChild>
            <button className="px-5 py-2.5 bg-primary hover:bg-primary/90 text-primary-foreground rounded-lg shadow-lg shadow-primary/25 font-bold flex items-center gap-2 transition-all hover:scale-105 active:scale-95">
              <Plus className="w-5 h-5" />
              Add Player
            </button>
          </DialogTrigger>
          <DialogContent className="bg-card border-border sm:max-w-[600px]">
            <DialogHeader>
              <DialogTitle className="text-xl font-display text-primary">Sign New Player</DialogTitle>
            </DialogHeader>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4 mt-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-xs font-bold text-muted-foreground uppercase">Name</label>
                  <input {...form.register("name")} className="w-full bg-background border border-border rounded px-3 py-2 text-white focus:ring-1 focus:ring-primary focus:border-primary outline-none" placeholder="Player Name" />
                </div>
                <div className="space-y-2">
                  <label className="text-xs font-bold text-muted-foreground uppercase">Nationality</label>
                  <input {...form.register("nationality")} className="w-full bg-background border border-border rounded px-3 py-2 text-white focus:ring-1 focus:ring-primary focus:border-primary outline-none" placeholder="Country" />
                </div>
                <div className="space-y-2">
                  <label className="text-xs font-bold text-muted-foreground uppercase">Position</label>
                  <select {...form.register("position")} className="w-full bg-background border border-border rounded px-3 py-2 text-white focus:ring-1 focus:ring-primary focus:border-primary outline-none">
                    <option value="GK">Goalkeeper</option>
                    <option value="DEF">Defender</option>
                    <option value="MID">Midfielder</option>
                    <option value="FWD">Forward</option>
                  </select>
                </div>
                <div className="space-y-2">
                  <label className="text-xs font-bold text-muted-foreground uppercase">Jersey #</label>
                  <input type="number" {...form.register("jerseyNumber")} className="w-full bg-background border border-border rounded px-3 py-2 text-white focus:ring-1 focus:ring-primary focus:border-primary outline-none" />
                </div>
                <div className="space-y-2">
                  <label className="text-xs font-bold text-muted-foreground uppercase">Age</label>
                  <input type="number" {...form.register("age")} className="w-full bg-background border border-border rounded px-3 py-2 text-white focus:ring-1 focus:ring-primary focus:border-primary outline-none" />
                </div>
                <div className="space-y-2">
                  <label className="text-xs font-bold text-muted-foreground uppercase">Market Value ($)</label>
                  <input type="number" {...form.register("marketValue")} className="w-full bg-background border border-border rounded px-3 py-2 text-white focus:ring-1 focus:ring-primary focus:border-primary outline-none" />
                </div>
                 <div className="space-y-2">
                  <label className="text-xs font-bold text-muted-foreground uppercase">Weekly Wage ($)</label>
                  <input type="number" {...form.register("wage")} className="w-full bg-background border border-border rounded px-3 py-2 text-white focus:ring-1 focus:ring-primary focus:border-primary outline-none" />
                </div>
                 <div className="space-y-2">
                  <label className="text-xs font-bold text-muted-foreground uppercase">Contract Ends</label>
                  <input type="date" {...form.register("contractExpires")} className="w-full bg-background border border-border rounded px-3 py-2 text-white focus:ring-1 focus:ring-primary focus:border-primary outline-none" />
                </div>
              </div>
              <button type="submit" disabled={form.formState.isSubmitting} className="w-full py-3 bg-primary text-primary-foreground font-bold rounded-lg mt-6 hover:brightness-110 transition-all">
                {form.formState.isSubmitting ? "Signing..." : "Complete Signing"}
              </button>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Filters */}
      <div className="glass-card p-4 rounded-xl flex flex-col sm:flex-row gap-4 items-center justify-between">
        <div className="relative w-full sm:w-96">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <input 
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full bg-background/50 border border-white/10 rounded-lg pl-10 pr-4 py-2 text-sm focus:ring-1 focus:ring-primary focus:border-primary outline-none transition-all placeholder:text-muted-foreground"
            placeholder="Search player name..."
          />
        </div>
        <div className="flex gap-2 p-1 bg-background/50 rounded-lg border border-white/5">
          {["ALL", "GK", "DEF", "MID", "FWD"].map(pos => (
            <button
              key={pos}
              onClick={() => setPositionFilter(pos)}
              className={`px-4 py-1.5 rounded-md text-xs font-bold transition-all ${positionFilter === pos ? "bg-secondary text-white shadow-md" : "text-muted-foreground hover:text-white"}`}
            >
              {pos}
            </button>
          ))}
        </div>
      </div>

      {isLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {[1,2,3,4,5,6,7,8].map(i => (
             <div key={i} className="h-64 rounded-xl bg-card/30 animate-pulse" />
          ))}
        </div>
      ) : (
        <div className="space-y-10">
          {forwards.length > 0 && (
            <section>
              <h2 className="text-sm font-bold text-muted-foreground uppercase mb-4 pl-1 border-l-2 border-red-500 flex items-center gap-2">
                Forwards <span className="text-[10px] bg-red-500/20 text-red-500 px-1.5 rounded">{forwards.length}</span>
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                {forwards.map(player => <PlayerCard key={player.id} player={player} />)}
              </div>
            </section>
          )}

          {midfielders.length > 0 && (
            <section>
               <h2 className="text-sm font-bold text-muted-foreground uppercase mb-4 pl-1 border-l-2 border-green-500 flex items-center gap-2">
                Midfielders <span className="text-[10px] bg-green-500/20 text-green-500 px-1.5 rounded">{midfielders.length}</span>
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                {midfielders.map(player => <PlayerCard key={player.id} player={player} />)}
              </div>
            </section>
          )}

          {defenders.length > 0 && (
            <section>
              <h2 className="text-sm font-bold text-muted-foreground uppercase mb-4 pl-1 border-l-2 border-blue-500 flex items-center gap-2">
                Defenders <span className="text-[10px] bg-blue-500/20 text-blue-500 px-1.5 rounded">{defenders.length}</span>
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                {defenders.map(player => <PlayerCard key={player.id} player={player} />)}
              </div>
            </section>
          )}

          {goalkeepers.length > 0 && (
            <section>
              <h2 className="text-sm font-bold text-muted-foreground uppercase mb-4 pl-1 border-l-2 border-yellow-500 flex items-center gap-2">
                Goalkeepers <span className="text-[10px] bg-yellow-500/20 text-yellow-500 px-1.5 rounded">{goalkeepers.length}</span>
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                {goalkeepers.map(player => <PlayerCard key={player.id} player={player} />)}
              </div>
            </section>
          )}
        </div>
      )}
    </div>
  );
}

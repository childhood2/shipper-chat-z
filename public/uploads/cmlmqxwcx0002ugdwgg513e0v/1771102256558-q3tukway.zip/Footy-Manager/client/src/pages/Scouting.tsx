import { useScouting } from "@/hooks/use-scouting";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Star, Shield, Users, MapPin, ClipboardList } from "lucide-react";

export default function Scouting() {
  const { data: reports, isLoading } = useScouting();

  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-display text-white">Scouting Hub</h1>
          <p className="text-muted-foreground">Monitor talent and scout recommendations.</p>
        </div>
        <button className="px-4 py-2 bg-primary text-primary-foreground rounded-lg font-bold text-sm shadow-lg shadow-primary/20 flex items-center gap-2">
            <ClipboardList className="w-4 h-4" /> New Assignment
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {reports?.map(report => (
          <Card key={report.id} className="overflow-hidden border-border bg-card/50 backdrop-blur">
            <div className="h-2 bg-primary" />
            <CardHeader>
              <div className="flex justify-between items-start">
                <div>
                  <CardTitle className="text-xl">{report.playerName}</CardTitle>
                  <p className="text-sm text-muted-foreground">{report.currentClub} • {report.age} years</p>
                </div>
                <Badge className="bg-yellow-500/20 text-yellow-500 border-yellow-500/20 flex gap-1">
                  <Star className="w-3 h-3 fill-current" /> {report.rating}
                </Badge>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1">
                  <span className="text-[10px] text-muted-foreground uppercase tracking-wider">Position</span>
                  <div className="flex items-center gap-2 text-sm text-white">
                    <Shield className="w-4 h-4 text-primary" /> {report.position}
                  </div>
                </div>
                <div className="space-y-1">
                  <span className="text-[10px] text-muted-foreground uppercase tracking-wider">Potential</span>
                  <div className="flex items-center gap-2 text-sm text-white">
                    <TrendingUp className="w-4 h-4 text-green-500" /> {report.potential}
                  </div>
                </div>
              </div>

              <div className="p-3 bg-secondary/30 rounded-lg">
                <p className="text-xs text-muted-foreground leading-relaxed italic">
                  "{report.notes}"
                </p>
              </div>

              <div className="pt-4 border-t border-border flex justify-between items-center">
                <div className="flex items-center gap-2 text-xs text-muted-foreground">
                    <Users className="w-3 h-3" /> Scout: {report.scoutName}
                </div>
                <Badge variant="outline" className="text-[10px] uppercase font-bold">{report.status}</Badge>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card className="lg:col-span-2">
            <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                    <MapPin className="w-5 h-5 text-primary" /> Active Assignments
                </CardTitle>
            </CardHeader>
            <CardContent>
                <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 bg-secondary/20 rounded-lg border border-white/5">
                        <div className="flex items-center gap-3">
                            <Badge className="bg-blue-500">EU</Badge>
                            <span className="text-sm text-white">Northern Europe - U21 Prospects</span>
                        </div>
                        <span className="text-xs text-muted-foreground">80% Complete</span>
                    </div>
                    <div className="flex items-center justify-between p-3 bg-secondary/20 rounded-lg border border-white/5">
                        <div className="flex items-center gap-3">
                            <Badge className="bg-green-500">SA</Badge>
                            <span className="text-sm text-white">South America - Liberatores Cup</span>
                        </div>
                        <span className="text-xs text-muted-foreground">In Progress</span>
                    </div>
                </div>
            </CardContent>
        </Card>
        
        <Card>
            <CardHeader>
                <CardTitle className="text-lg">Scout Performance</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                    <span className="text-sm text-muted-foreground">Reports Submitted</span>
                    <span className="text-sm font-bold text-white">24</span>
                </div>
                <div className="flex items-center justify-between">
                    <span className="text-sm text-muted-foreground">Avg. Player Rating</span>
                    <span className="text-sm font-bold text-white">78.5</span>
                </div>
                <div className="flex items-center justify-between">
                    <span className="text-sm text-muted-foreground">Signings Made</span>
                    <span className="text-sm font-bold text-primary">4</span>
                </div>
            </CardContent>
        </Card>
      </div>
    </div>
  );
}

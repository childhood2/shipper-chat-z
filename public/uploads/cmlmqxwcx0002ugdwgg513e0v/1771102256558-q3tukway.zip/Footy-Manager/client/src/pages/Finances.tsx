import { useFinances } from "@/hooks/use-finances";
import { StatCard } from "@/components/StatCard";
import { DollarSign, PieChart, TrendingUp, TrendingDown } from "lucide-react";
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer, BarChart, Bar } from "recharts";

export default function Finances() {
  const { data: finances, isLoading } = useFinances();

  const totalIncome = finances?.filter(f => f.amount > 0).reduce((sum, f) => sum + f.amount, 0) || 0;
  const totalExpenses = finances?.filter(f => f.amount < 0).reduce((sum, f) => sum + Math.abs(f.amount), 0) || 0;
  const balance = totalIncome - totalExpenses;

  // Transform data for charts
  const chartData = finances?.map(f => ({
    name: new Date(f.date!).toLocaleDateString(undefined, { month: 'short', day: 'numeric' }),
    amount: f.amount,
    type: f.type
  })).slice(0, 10);

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <div>
        <h1 className="text-3xl font-display text-white">Financial Hub</h1>
        <p className="text-muted-foreground">Budget allocation, revenue streams and expenses.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <StatCard 
            title="Total Revenue" 
            value={`$${(totalIncome / 1000000).toFixed(2)}M`} 
            icon={<TrendingUp className="w-6 h-6 text-green-500" />}
            trend="up"
            trendValue="+12%"
            className="border-green-500/20"
        />
        <StatCard 
            title="Total Expenses" 
            value={`$${(totalExpenses / 1000000).toFixed(2)}M`} 
            icon={<TrendingDown className="w-6 h-6 text-red-500" />}
            trend="down"
            trendValue="+5%"
            className="border-red-500/20"
        />
         <StatCard 
            title="Net Balance" 
            value={`$${(balance / 1000000).toFixed(2)}M`} 
            icon={<DollarSign className="w-6 h-6 text-primary" />}
            className="border-primary/20 bg-primary/5"
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 h-[400px]">
         <div className="glass-card p-6 flex flex-col">
            <h3 className="font-bold text-lg mb-6 text-white">Cash Flow</h3>
            <div className="flex-1">
                <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={chartData}>
                        <defs>
                            <linearGradient id="colorAmount" x1="0" y1="0" x2="0" y2="1">
                                <stop offset="5%" stopColor="var(--primary)" stopOpacity={0.3}/>
                                <stop offset="95%" stopColor="var(--primary)" stopOpacity={0}/>
                            </linearGradient>
                        </defs>
                        <XAxis dataKey="name" stroke="#64748b" fontSize={12} tickLine={false} axisLine={false} />
                        <Tooltip 
                            contentStyle={{ backgroundColor: '#1a202c', border: 'none', borderRadius: '8px' }}
                            itemStyle={{ color: '#fff' }}
                        />
                        <Area type="monotone" dataKey="amount" stroke="var(--primary)" fillOpacity={1} fill="url(#colorAmount)" />
                    </AreaChart>
                </ResponsiveContainer>
            </div>
         </div>

          <div className="glass-card p-6 flex flex-col">
            <h3 className="font-bold text-lg mb-6 text-white">Transaction History</h3>
            <div className="overflow-auto custom-scrollbar flex-1">
                <table className="w-full text-sm">
                    <thead className="text-muted-foreground border-b border-white/10">
                        <tr>
                            <th className="text-left pb-2 font-medium">Description</th>
                            <th className="text-left pb-2 font-medium">Category</th>
                            <th className="text-right pb-2 font-medium">Amount</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-white/5">
                        {finances?.map(f => (
                            <tr key={f.id} className="hover:bg-white/5 transition-colors">
                                <td className="py-3 text-white">{f.description}</td>
                                <td className="py-3 text-muted-foreground">{f.category}</td>
                                <td className={`py-3 text-right font-mono font-bold ${f.amount > 0 ? 'text-green-400' : 'text-red-400'}`}>
                                    {f.amount > 0 ? "+" : ""}{f.amount.toLocaleString()}
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
         </div>
      </div>
    </div>
  );
}

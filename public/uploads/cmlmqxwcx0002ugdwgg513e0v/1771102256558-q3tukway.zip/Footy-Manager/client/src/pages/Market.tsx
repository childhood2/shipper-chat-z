import { usePlayers } from "@/hooks/use-players";
import { useScouting } from "@/hooks/use-scouting";
import { PlayerCard } from "@/components/PlayerCard";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Search, Filter, TrendingUp, Target } from "lucide-react";
import { useState } from "react";

export default function Market() {
  const { data: players } = usePlayers();
  const { data: scouting } = useScouting();
  const [search, setSearch] = useState("");

  const filteredScouting = scouting?.filter(p => 
    p.playerName.toLowerCase().includes(search.toLowerCase()) ||
    p.position.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      <div>
        <h1 className="text-3xl font-display text-white">Transfer Market</h1>
        <p className="text-muted-foreground">Global player discovery and transfer management.</p>
      </div>

      <div className="flex flex-col md:flex-row gap-4 items-center justify-between">
        <div className="relative w-full md:w-96">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <input 
            type="text" 
            placeholder="Search players, positions, clubs..." 
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full bg-card border border-border rounded-lg pl-10 pr-4 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-primary"
          />
        </div>
        <div className="flex gap-2">
            <button className="px-3 py-1.5 bg-secondary text-white rounded border border-white/10 text-xs flex items-center gap-2">
                <Filter className="w-3 h-3" /> Filters
            </button>
            <Badge variant="outline" className="bg-primary/10 text-primary border-primary/20">Budget: $50.0M</Badge>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-4">
          <h3 className="font-bold text-white flex items-center gap-2">
            <Target className="w-5 h-5 text-primary" />
            Top Scouting Targets
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {filteredScouting?.map(report => (
              <Card key={report.id} className="hover-elevate">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <div className="space-y-1">
                    <CardTitle className="text-base">{report.playerName}</CardTitle>
                    <p className="text-xs text-muted-foreground">{report.currentClub} • {report.position}</p>
                  </div>
                  <Badge className={report.rating >= 85 ? "bg-green-500" : "bg-primary"}>
                    {report.rating}
                  </Badge>
                </CardHeader>
                <CardContent>
                  <div className="flex justify-between text-xs mb-3">
                    <span className="text-muted-foreground">Potential</span>
                    <span className="text-white font-bold">{report.potential}</span>
                  </div>
                  <div className="flex justify-between text-xs mb-3">
                    <span className="text-muted-foreground">Market Value</span>
                    <span className="text-white font-bold">${(report.marketValue / 1000000).toFixed(1)}M</span>
                  </div>
                  <div className="pt-2 border-t border-border flex justify-between items-center">
                    <Badge variant="outline" className="text-[10px]">{report.status}</Badge>
                    <button className="text-[10px] text-primary hover:underline font-bold uppercase tracking-wider">View Details</button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        <div className="space-y-4">
          <h3 className="font-bold text-white flex items-center gap-2">
            <TrendingUp className="w-5 h-5 text-primary" />
            Market Trends
          </h3>
          <Card className="bg-primary/5 border-primary/20">
            <CardContent className="pt-6">
              <div className="space-y-4">
                <div className="flex items-start gap-3">
                  <div className="w-8 h-8 rounded bg-green-500/20 flex items-center justify-center shrink-0">
                    <TrendingUp className="w-4 h-4 text-green-500" />
                  </div>
                  <div>
                    <p className="text-sm font-bold text-white">Value Increasing</p>
                    <p className="text-xs text-muted-foreground">Defender market values up 12% this month.</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <div className="w-8 h-8 rounded bg-primary/20 flex items-center justify-center shrink-0">
                    <Search className="w-4 h-4 text-primary" />
                  </div>
                  <div>
                    <p className="text-sm font-bold text-white">Hot Prospect</p>
                    <p className="text-xs text-muted-foreground">3 clubs monitoring Joao Neves.</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}

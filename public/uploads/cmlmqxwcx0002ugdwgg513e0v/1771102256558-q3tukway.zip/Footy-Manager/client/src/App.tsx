import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { SidebarProvider } from "@/components/ui/sidebar";
import { Sidebar } from "@/components/Sidebar";
import NotFound from "@/pages/not-found";
import Dashboard from "@/pages/Dashboard";
import Squad from "@/pages/Squad";
import Matches from "@/pages/Matches";
import Market from "@/pages/Market";
import Scouting from "@/pages/Scouting";
import Analytics from "@/pages/Analytics";
import Finances from "@/pages/Finances";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Dashboard} />
      <Route path="/squad" component={Squad} />
      <Route path="/matches" component={Matches} />
      <Route path="/market" component={Market} />
      <Route path="/analytics" component={Analytics} />
      <Route path="/finances" component={Finances} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <SidebarProvider>
          <div className="flex h-screen w-full bg-background overflow-hidden">
            <Sidebar />
            <main className="flex-1 overflow-y-auto p-4 md:p-8 ml-64">
              <Router />
            </main>
          </div>
          <Toaster />
        </SidebarProvider>
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;

import { Link, useLocation } from "wouter";
import { LayoutDashboard, Users, Calendar, TrendingUp, Binoculars, BarChart3, Wallet, LogOut, Github } from "lucide-react";
import logo from "@assets/logo1_1770751281612.png";
import { cn } from "@/lib/utils";

const navigation = [
  { name: "Dashboard", href: "/", icon: LayoutDashboard },
  { name: "Squad", href: "/squad", icon: Users },
  { name: "Matches", href: "/matches", icon: Calendar },
  { name: "Market", href: "/market", icon: TrendingUp },
  { name: "Analytics", href: "/analytics", icon: BarChart3 },
  { name: "Finances", href: "/finances", icon: Wallet },
];

export function Sidebar() {
  const [location] = useLocation();

  return (
    <div className="flex flex-col h-screen w-64 bg-secondary border-r border-border shrink-0 fixed left-0 top-0 z-50">
      <div className="p-6 flex flex-col items-center border-b border-border/50">
        <a href="https://techapollos.com" target="_blank" rel="noopener noreferrer" className="hover:opacity-80 transition-opacity">
            <img src={logo} alt="Apollo FC" className="h-20 w-auto object-contain drop-shadow-lg" />
        </a>
        <h1 className="mt-4 text-xl font-bold tracking-wider text-primary">APOLLO FC</h1>
        <p className="text-xs text-muted-foreground uppercase tracking-[0.2em]">Manager Mode</p>
      </div>

      <nav className="flex-1 px-4 py-6 space-y-1 overflow-y-auto custom-scrollbar">
        {navigation.map((item) => {
          const isActive = location === item.href;
          return (
            <Link key={item.name} href={item.href} className={cn(
              "flex items-center gap-3 px-4 py-3 text-sm font-medium rounded-lg transition-all duration-200 group relative overflow-hidden",
              isActive 
                ? "bg-primary text-primary-foreground shadow-lg shadow-primary/20" 
                : "text-muted-foreground hover:bg-white/5 hover:text-white"
            )}>
              <item.icon className={cn("w-5 h-5", isActive ? "animate-pulse" : "group-hover:text-primary transition-colors")} />
              {item.name}
              {isActive && (
                <div className="absolute inset-y-0 right-0 w-1 bg-white/20 rounded-l-full" />
              )}
            </Link>
          );
        })}
      </nav>

      <div className="p-4 border-t border-border/50 bg-black/20">
        <div className="flex items-center justify-between px-2 mb-4">
          <span className="text-xs text-muted-foreground font-mono">v2.4.0</span>
          <a href="https://github.com/sostenesapollo" target="_blank" rel="noreferrer" className="text-muted-foreground hover:text-white transition-colors">
            <Github className="w-4 h-4" />
          </a>
        </div>
        <button className="w-full flex items-center justify-center gap-2 px-4 py-2 text-sm text-destructive hover:bg-destructive/10 rounded-lg transition-colors border border-destructive/20 hover:border-destructive/50">
          <LogOut className="w-4 h-4" />
          Sign Out
        </button>
        <div className="mt-4 text-[10px] text-center text-muted-foreground/50">
          Made by Apollo Technology © 2026
        </div>
      </div>
    </div>
  );
}

import { useState, useMemo } from "react";
import { cn } from "@/lib/utils";
import { User, Shirt } from "lucide-react";

type Position = {
  id: string;
  top: string;
  left: string;
  role: string;
};

const formations: Record<string, Position[]> = {
  "4-3-3": [
    { id: "gk", top: "90%", left: "50%", role: "GK" },
    { id: "lb", top: "70%", left: "15%", role: "LB" },
    { id: "lcb", top: "75%", left: "38%", role: "CB" },
    { id: "rcb", top: "75%", left: "62%", role: "CB" },
    { id: "rb", top: "70%", left: "85%", role: "RB" },
    { id: "cm1", top: "50%", left: "30%", role: "CM" },
    { id: "cm2", top: "50%", left: "70%", role: "CM" },
    { id: "cam", top: "40%", left: "50%", role: "CAM" },
    { id: "lw", top: "20%", left: "20%", role: "LW" },
    { id: "st", top: "15%", left: "50%", role: "ST" },
    { id: "rw", top: "20%", left: "80%", role: "RW" },
  ],
  "4-4-2": [
    { id: "gk", top: "90%", left: "50%", role: "GK" },
    { id: "lb", top: "70%", left: "15%", role: "LB" },
    { id: "lcb", top: "75%", left: "38%", role: "CB" },
    { id: "rcb", top: "75%", left: "62%", role: "CB" },
    { id: "rb", top: "70%", left: "85%", role: "RB" },
    { id: "lm", top: "45%", left: "15%", role: "LM" },
    { id: "cm1", top: "50%", left: "40%", role: "CM" },
    { id: "cm2", top: "50%", left: "60%", role: "CM" },
    { id: "rm", top: "45%", left: "85%", role: "RM" },
    { id: "st1", top: "20%", left: "40%", role: "ST" },
    { id: "st2", top: "20%", left: "60%", role: "ST" },
  ],
  "3-5-2": [
    { id: "gk", top: "90%", left: "50%", role: "GK" },
    { id: "lcb", top: "75%", left: "25%", role: "CB" },
    { id: "cb", top: "78%", left: "50%", role: "CB" },
    { id: "rcb", top: "75%", left: "75%", role: "CB" },
    { id: "lwb", top: "55%", left: "10%", role: "LWB" },
    { id: "cdm", top: "60%", left: "50%", role: "CDM" },
    { id: "rwb", top: "55%", left: "90%", role: "RWB" },
    { id: "cm1", top: "45%", left: "35%", role: "CM" },
    { id: "cm2", top: "45%", left: "65%", role: "CM" },
    { id: "st1", top: "20%", left: "40%", role: "ST" },
    { id: "st2", top: "20%", left: "60%", role: "ST" },
  ],
};

export function LineupBuilder() {
  const [formation, setFormation] = useState("4-3-3");

  const positions = useMemo(() => formations[formation] || formations["4-3-3"], [formation]);

  return (
    <div className="bg-card rounded-xl border border-border overflow-hidden h-full flex flex-col">
      <div className="p-4 border-b border-border flex justify-between items-center bg-secondary/30">
        <h3 className="font-bold text-lg uppercase tracking-wider flex items-center gap-2">
            <Shirt className="w-5 h-5 text-primary" />
            Match Strategy
        </h3>
        <select 
            value={formation}
            onChange={(e) => setFormation(e.target.value)}
            className="bg-background border border-border rounded px-3 py-1 text-sm focus:outline-none focus:ring-1 focus:ring-primary"
        >
            <option value="4-3-3">4-3-3 Attack</option>
            <option value="4-4-2">4-4-2 Flat</option>
            <option value="3-5-2">3-5-2 Wing</option>
        </select>
      </div>
      
      <div className="flex-1 relative bg-[#2a4d1a] overflow-hidden">
        {/* Pitch Markings */}
        <div className="absolute inset-4 border-2 border-white/20 rounded-sm">
            {/* Center Circle */}
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-32 h-32 border-2 border-white/20 rounded-full" />
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-2 h-2 bg-white/40 rounded-full" />
            
            {/* Center Line */}
            <div className="absolute top-1/2 left-0 w-full h-0.5 bg-white/20" />
            
            {/* Penalty Area Top */}
            <div className="absolute top-0 left-1/2 -translate-x-1/2 w-64 h-32 border-x-2 border-b-2 border-white/20" />
            
            {/* Penalty Area Bottom */}
            <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-64 h-32 border-x-2 border-t-2 border-white/20" />
        </div>

        {/* Players on Pitch */}
        {positions.map((pos) => (
            <div 
                key={pos.id}
                className="absolute transform -translate-x-1/2 -translate-y-1/2 flex flex-col items-center group cursor-pointer hover:z-10 transition-all duration-500 ease-in-out"
                style={{ top: pos.top, left: pos.left }}
            >
                <div className="w-10 h-10 rounded-full bg-secondary border-2 border-white/20 shadow-xl flex items-center justify-center transition-transform group-hover:scale-110 group-hover:border-primary">
                    <User className="w-5 h-5 text-white/50" />
                </div>
                <div className="mt-1 bg-black/60 backdrop-blur px-2 py-0.5 rounded text-[10px] font-bold text-white uppercase opacity-70 group-hover:opacity-100 group-hover:bg-primary transition-all">
                    {pos.role}
                </div>
            </div>
        ))}
      </div>
    </div>
  );
}

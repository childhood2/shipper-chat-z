import { ReactNode } from "react";
import { cn } from "@/lib/utils";
import { ArrowUpRight, ArrowDownRight, Minus } from "lucide-react";

interface StatCardProps {
  title: string;
  value: string | number;
  icon?: ReactNode;
  trend?: "up" | "down" | "neutral";
  trendValue?: string;
  description?: string;
  className?: string;
}

export function StatCard({ title, value, icon, trend, trendValue, description, className }: StatCardProps) {
  return (
    <div className={cn("glass-card p-6 rounded-xl relative overflow-hidden group hover:bg-card/80 transition-all duration-300", className)}>
      <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity scale-150 transform translate-x-2 -translate-y-2">
        {icon}
      </div>
      
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-sm font-medium text-muted-foreground uppercase tracking-wider">{title}</h3>
        {icon && <div className="text-primary opacity-80">{icon}</div>}
      </div>

      <div className="flex items-end gap-3">
        <div className="text-3xl font-bold font-mono text-foreground tracking-tight">{value}</div>
        
        {trend && (
          <div className={cn(
            "flex items-center text-xs font-bold px-2 py-1 rounded-full mb-1",
            trend === "up" && "bg-green-500/10 text-green-500",
            trend === "down" && "bg-red-500/10 text-red-500",
            trend === "neutral" && "bg-gray-500/10 text-gray-500",
          )}>
            {trend === "up" && <ArrowUpRight className="w-3 h-3 mr-1" />}
            {trend === "down" && <ArrowDownRight className="w-3 h-3 mr-1" />}
            {trend === "neutral" && <Minus className="w-3 h-3 mr-1" />}
            {trendValue}
          </div>
        )}
      </div>
      
      {description && (
        <p className="mt-2 text-xs text-muted-foreground/80">{description}</p>
      )}
    </div>
  );
}

import { User, Shield, Activity } from "lucide-react";
import { cn } from "@/lib/utils";
import type { Player } from "@shared/schema";

interface PlayerCardProps {
  player: Player;
  variant?: "compact" | "full";
}

export function PlayerCard({ player, variant = "full" }: PlayerCardProps) {
  const getStatusColor = (status: string) => {
    switch (status.toLowerCase()) {
      case "fit": return "bg-green-500 shadow-[0_0_10px_rgba(34,197,94,0.4)]";
      case "injured": return "bg-red-500 shadow-[0_0_10px_rgba(239,68,68,0.4)]";
      case "suspended": return "bg-yellow-500 shadow-[0_0_10px_rgba(234,179,8,0.4)]";
      default: return "bg-gray-500";
    }
  };

  const getPositionColor = (pos: string) => {
    if (pos.includes("GK")) return "text-yellow-400";
    if (pos.includes("DEF")) return "text-blue-400";
    if (pos.includes("MID")) return "text-green-400";
    if (pos.includes("FWD")) return "text-red-400";
    return "text-white";
  };

  if (variant === "compact") {
    return (
      <div className="flex items-center justify-between p-3 rounded-lg bg-card/40 border border-white/5 hover:bg-card/60 transition-colors group cursor-pointer">
        <div className="flex items-center gap-3">
          <div className="relative">
            <div className="w-10 h-10 rounded-full bg-secondary flex items-center justify-center overflow-hidden border border-white/10">
              {player.photoUrl ? (
                <img src={player.photoUrl} alt={player.name} className="w-full h-full object-cover" />
              ) : (
                <User className="w-5 h-5 text-muted-foreground" />
              )}
            </div>
            <div className={cn("absolute -bottom-0.5 -right-0.5 w-3 h-3 rounded-full border-2 border-card", getStatusColor(player.status))} />
          </div>
          <div>
            <div className="font-bold text-sm text-foreground group-hover:text-primary transition-colors">{player.name}</div>
            <div className="text-xs text-muted-foreground flex items-center gap-1.5">
              <span className={cn("font-mono font-bold", getPositionColor(player.position))}>{player.position}</span>
              <span className="w-1 h-1 rounded-full bg-white/20" />
              <span>#{player.jerseyNumber}</span>
            </div>
          </div>
        </div>
        <div className="text-right">
          <div className="text-xs font-mono text-white font-bold">{player.averageRating}</div>
          <div className="text-[10px] text-muted-foreground uppercase">RTG</div>
        </div>
      </div>
    );
  }

  return (
    <div className="glass-card rounded-xl overflow-hidden hover:translate-y-[-4px] transition-all duration-300 group relative">
      <div className="h-32 bg-gradient-to-b from-secondary to-card relative overflow-hidden">
        {/* Background Pattern */}
        <div className="absolute inset-0 opacity-10 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-primary via-transparent to-transparent" />
        
        {/* Jersey Number Watermark */}
        <div className="absolute -right-4 -top-6 text-9xl font-black text-white/5 select-none font-display">
          {player.jerseyNumber}
        </div>

        <div className="absolute bottom-0 left-0 w-full p-4 flex items-end gap-4">
          <div className="relative z-10 w-20 h-20 rounded-xl bg-background border-2 border-border shadow-xl overflow-hidden flex-shrink-0">
            {player.photoUrl ? (
              <img src={player.photoUrl} alt={player.name} className="w-full h-full object-cover" />
            ) : (
              <User className="w-10 h-10 text-muted-foreground absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2" />
            )}
          </div>
          <div className="mb-1">
            <h3 className="text-lg font-bold text-white leading-tight group-hover:text-primary transition-colors">{player.name}</h3>
            <div className="flex items-center gap-2 mt-1">
              <span className={cn("text-xs font-bold px-1.5 py-0.5 rounded bg-white/5 border border-white/10", getPositionColor(player.position))}>
                {player.position}
              </span>
              <span className="text-xs text-muted-foreground">{player.nationality}</span>
            </div>
          </div>
        </div>
      </div>

      <div className="p-4 grid grid-cols-2 gap-4">
        <div className="space-y-1">
          <div className="text-[10px] uppercase text-muted-foreground tracking-wider">Value</div>
          <div className="text-sm font-mono font-bold text-green-400">
            ${(player.marketValue / 1000000).toFixed(1)}M
          </div>
        </div>
        <div className="space-y-1 text-right">
          <div className="text-[10px] uppercase text-muted-foreground tracking-wider">Form</div>
          <div className="text-sm font-mono font-bold text-primary">{player.averageRating}</div>
        </div>

        <div className="col-span-2 pt-3 border-t border-white/5 flex items-center justify-between">
           <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
             <Activity className="w-3 h-3" />
             <span>{player.appearances} Apps</span>
           </div>
           <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
             <div className={cn("w-2 h-2 rounded-full", getStatusColor(player.status))} />
             <span>{player.status}</span>
           </div>
        </div>
      </div>
    </div>
  );
}

import { Calendar, MapPin, Clock } from "lucide-react";
import { format } from "date-fns";
import type { Match } from "@shared/schema";
import { cn } from "@/lib/utils";

interface MatchCardProps {
  match: Match;
}

export function MatchCard({ match }: MatchCardProps) {
  const isFinished = match.status === "Played";
  const isLive = match.status === "Live";
  const date = new Date(match.date);

  return (
    <div className="glass-card rounded-xl p-4 border-l-4 border-l-primary hover:bg-card/80 transition-all cursor-pointer group">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2 text-xs text-muted-foreground">
          <Calendar className="w-3 h-3" />
          <span>{format(date, "EEE, MMM d")}</span>
          <span className="w-1 h-1 bg-white/20 rounded-full" />
          <span>{match.competition}</span>
        </div>
        {isLive && (
          <span className="flex items-center gap-1.5 text-[10px] font-bold text-red-500 uppercase bg-red-500/10 px-2 py-0.5 rounded animate-pulse">
            <span className="w-1.5 h-1.5 rounded-full bg-red-500" /> Live
          </span>
        )}
        {!isLive && !isFinished && (
          <span className="text-xs font-mono text-primary bg-primary/10 px-2 py-0.5 rounded">
            {format(date, "HH:mm")}
          </span>
        )}
      </div>

      <div className="flex items-center justify-between gap-4">
        {/* Home Team */}
        <div className={cn("flex-1 flex items-center gap-3", !match.isHome && "flex-row-reverse text-right")}>
          <div className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center border border-white/10 font-bold text-xs">
            {match.isHome ? "AFC" : match.opponent.substring(0, 3).toUpperCase()}
          </div>
          <span className={cn("font-bold text-sm", match.isHome && "text-primary")}>
            {match.isHome ? "Apollo FC" : match.opponent}
          </span>
        </div>

        {/* Score */}
        <div className="flex flex-col items-center min-w-[60px]">
          <div className="text-2xl font-mono font-bold tracking-widest bg-black/40 px-3 py-1 rounded border border-white/5">
            {isFinished || isLive ? (
              <>
                <span className={match.scoreFor && match.scoreFor > (match.scoreAgainst || 0) ? "text-green-400" : "text-white"}>{match.scoreFor ?? 0}</span>
                <span className="text-muted-foreground mx-1">-</span>
                <span className={match.scoreAgainst && match.scoreAgainst > (match.scoreFor || 0) ? "text-red-400" : "text-white"}>{match.scoreAgainst ?? 0}</span>
              </>
            ) : (
              <span className="text-lg text-muted-foreground">VS</span>
            )}
          </div>
          {isFinished && (
             <span className="text-[10px] text-muted-foreground mt-1">FT</span>
          )}
        </div>

        {/* Away Team */}
        <div className={cn("flex-1 flex items-center gap-3", match.isHome && "flex-row-reverse text-right")}>
          <div className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center border border-white/10 font-bold text-xs">
            {!match.isHome ? "AFC" : match.opponent.substring(0, 3).toUpperCase()}
          </div>
          <span className={cn("font-bold text-sm", !match.isHome && "text-primary")}>
            {!match.isHome ? "Apollo FC" : match.opponent}
          </span>
        </div>
      </div>
      
      {isFinished && (
        <div className="mt-4 pt-3 border-t border-white/5 grid grid-cols-3 gap-2">
          <div className="text-center">
            <p className="text-[8px] text-muted-foreground uppercase">Possession</p>
            <p className="text-[10px] font-bold text-white">{match.possession}%</p>
          </div>
          <div className="text-center">
            <p className="text-[8px] text-muted-foreground uppercase">xG</p>
            <p className="text-[10px] font-bold text-white">{match.xgFor}</p>
          </div>
          <div className="text-center">
            <p className="text-[8px] text-muted-foreground uppercase">Formation</p>
            <p className="text-[10px] font-bold text-white">{match.formation}</p>
          </div>
        </div>
      )}
      
      <div className="mt-4 pt-3 border-t border-white/5 flex justify-center">
        <div className="flex items-center gap-2 text-[10px] text-muted-foreground">
            <MapPin className="w-3 h-3" />
            {match.isHome ? "Apollo Arena" : "Away Ground"}
        </div>
      </div>
    </div>
  );
}

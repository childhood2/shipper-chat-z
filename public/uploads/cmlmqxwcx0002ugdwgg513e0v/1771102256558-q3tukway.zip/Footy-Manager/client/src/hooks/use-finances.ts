import { useQuery } from "@tanstack/react-query";
import { api } from "@shared/routes";

export function useFinances() {
  return useQuery({
    queryKey: [api.finances.list.path],
    queryFn: async () => {
      const res = await fetch(api.finances.list.path);
      if (!res.ok) throw new Error("Failed to fetch finances");
      return api.finances.list.responses[200].parse(await res.json());
    },
  });
}

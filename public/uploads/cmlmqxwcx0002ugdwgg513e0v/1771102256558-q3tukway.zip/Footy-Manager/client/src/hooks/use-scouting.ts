import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, type InsertScoutReport } from "@shared/routes";

export function useScouting() {
  return useQuery({
    queryKey: [api.scouting.list.path],
    queryFn: async () => {
      const res = await fetch(api.scouting.list.path);
      if (!res.ok) throw new Error("Failed to fetch scouting reports");
      return api.scouting.list.responses[200].parse(await res.json());
    },
  });
}

export function useCreateScoutReport() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (data: InsertScoutReport) => {
      const validated = api.scouting.create.input.parse(data);
      const res = await fetch(api.scouting.create.path, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(validated),
      });
      if (!res.ok) throw new Error("Failed to create scouting report");
      return api.scouting.create.responses[201].parse(await res.json());
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: [api.scouting.list.path] }),
  });
}

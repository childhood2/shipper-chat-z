import { pgTable, text, serial, integer, boolean, timestamp, jsonb, date } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// === PLAYERS ===
export const players = pgTable("players", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  position: text("position").notNull(), // GK, DEF, MID, FWD
  jerseyNumber: integer("jersey_number").notNull(),
  nationality: text("nationality").notNull(),
  age: integer("age").notNull(),
  status: text("status").notNull().default("Fit"), // Fit, Injured, Suspended
  marketValue: integer("market_value").notNull(), // In dollars
  wage: integer("wage").notNull(), // Weekly wage
  contractExpires: date("contract_expires").notNull(),
  photoUrl: text("photo_url"),
  
  // Aggregated Stats (simplified for MVP)
  appearances: integer("appearances").default(0),
  goals: integer("goals").default(0),
  assists: integer("assists").default(0),
  averageRating: text("average_rating").default("0.0"), // Stored as text to preserve precision
});

// === MATCHES ===
export const matches = pgTable("matches", {
  id: serial("id").primaryKey(),
  opponent: text("opponent").notNull(),
  isHome: boolean("is_home").default(true),
  date: timestamp("date").notNull(),
  competition: text("competition").notNull().default("League"),
  status: text("status").notNull().default("Scheduled"), // Scheduled, Played, Live
  
  // Results
  scoreFor: integer("score_for"),
  scoreAgainst: integer("score_against"),
  possession: integer("possession"), // Percentage
  xgFor: text("xg_for"), // Expected Goals
  xgAgainst: text("xg_against"),
  
  // Tactical
  formation: text("formation").default("4-3-3"),
});

// === SCOUTING ===
export const scoutingReports = pgTable("scouting_reports", {
  id: serial("id").primaryKey(),
  playerName: text("player_name").notNull(),
  currentClub: text("current_club").notNull(),
  age: integer("age").notNull(),
  position: text("position").notNull(),
  rating: integer("rating").notNull(), // 1-100
  potential: integer("potential").notNull(), // 1-100
  marketValue: integer("market_value").notNull(),
  scoutName: text("scout_name").notNull(),
  status: text("status").notNull().default("Monitoring"), // Monitoring, Shortlisted, Offered
  notes: text("notes"),
});

// === FINANCES ===
export const finances = pgTable("finances", {
  id: serial("id").primaryKey(),
  category: text("category").notNull(), // Ticket Sales, Sponsorship, Salaries, Transfers
  amount: integer("amount").notNull(), // Positive for income, negative for expense
  date: timestamp("date").defaultNow(),
  description: text("description"),
  type: text("type").notNull(), // Income, Expense
});

// === SCHEMAS ===
export const insertPlayerSchema = createInsertSchema(players).omit({ id: true });
export const insertMatchSchema = createInsertSchema(matches).omit({ id: true });
export const insertScoutReportSchema = createInsertSchema(scoutingReports).omit({ id: true });
export const insertFinanceSchema = createInsertSchema(finances).omit({ id: true });

// === TYPES ===
export type Player = typeof players.$inferSelect;
export type InsertPlayer = z.infer<typeof insertPlayerSchema>;
export type Match = typeof matches.$inferSelect;
export type InsertMatch = z.infer<typeof insertMatchSchema>;
export type ScoutReport = typeof scoutingReports.$inferSelect;
export type InsertScoutReport = z.infer<typeof insertScoutReportSchema>;
export type FinanceRecord = typeof finances.$inferSelect;
export type InsertFinanceRecord = z.infer<typeof insertFinanceSchema>;

export type UpdatePlayerRequest = Partial<InsertPlayer>;
export type UpdateMatchRequest = Partial<InsertMatch>;

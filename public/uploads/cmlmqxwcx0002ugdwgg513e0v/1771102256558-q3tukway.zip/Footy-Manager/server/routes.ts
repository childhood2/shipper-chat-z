import type { Express } from "express";
import type { Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  
  // === PLAYERS ROUTES ===
  app.get(api.players.list.path, async (req, res) => {
    const players = await storage.getPlayers();
    res.json(players);
  });

  app.get(api.players.get.path, async (req, res) => {
    const player = await storage.getPlayer(Number(req.params.id));
    if (!player) return res.status(404).json({ message: "Player not found" });
    res.json(player);
  });

  app.post(api.players.create.path, async (req, res) => {
    try {
      const input = api.players.create.input.parse(req.body);
      const player = await storage.createPlayer(input);
      res.status(201).json(player);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: err.errors[0].message });
      }
      throw err;
    }
  });

  app.patch(api.players.update.path, async (req, res) => {
    const player = await storage.updatePlayer(Number(req.params.id), req.body);
    res.json(player);
  });

  app.delete(api.players.delete.path, async (req, res) => {
    await storage.deletePlayer(Number(req.params.id));
    res.status(204).send();
  });

  // === MATCHES ROUTES ===
  app.get(api.matches.list.path, async (req, res) => {
    const matches = await storage.getMatches();
    res.json(matches);
  });

  app.get(api.matches.get.path, async (req, res) => {
    const match = await storage.getMatch(Number(req.params.id));
    if (!match) return res.status(404).json({ message: "Match not found" });
    res.json(match);
  });

  app.post(api.matches.create.path, async (req, res) => {
    try {
      const input = api.matches.create.input.parse(req.body);
      const match = await storage.createMatch(input);
      res.status(201).json(match);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: err.errors[0].message });
      }
      throw err;
    }
  });

  app.patch(api.matches.update.path, async (req, res) => {
    const match = await storage.updateMatch(Number(req.params.id), req.body);
    res.json(match);
  });

  // === SCOUTING ROUTES ===
  app.get(api.scouting.list.path, async (req, res) => {
    const reports = await storage.getScoutReports();
    res.json(reports);
  });

  app.post(api.scouting.create.path, async (req, res) => {
    try {
      const input = api.scouting.create.input.parse(req.body);
      const report = await storage.createScoutReport(input);
      res.status(201).json(report);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: err.errors[0].message });
      }
      throw err;
    }
  });

  // === FINANCE ROUTES ===
  app.get(api.finances.list.path, async (req, res) => {
    const records = await storage.getFinances();
    res.json(records);
  });

  // Initialize seed data
  seedDatabase();

  return httpServer;
}

async function seedDatabase() {
  const existingPlayers = await storage.getPlayers();
  if (existingPlayers.length === 0) {
    // Seed Players
    const players = [
      { name: "Marcus Rashford", position: "FWD", jerseyNumber: 10, nationality: "England", age: 26, marketValue: 60000000, wage: 200000, contractExpires: "2028-06-30", status: "Fit", appearances: 25, goals: 12, assists: 5, averageRating: "7.5" },
      { name: "Bruno Fernandes", position: "MID", jerseyNumber: 8, nationality: "Portugal", age: 29, marketValue: 70000000, wage: 240000, contractExpires: "2027-06-30", status: "Fit", appearances: 28, goals: 8, assists: 15, averageRating: "7.9" },
      { name: "André Onana", position: "GK", jerseyNumber: 24, nationality: "Cameroon", age: 27, marketValue: 35000000, wage: 120000, contractExpires: "2028-06-30", status: "Fit", appearances: 28, goals: 0, assists: 0, averageRating: "6.8" },
      { name: "Lisandro Martinez", position: "DEF", jerseyNumber: 6, nationality: "Argentina", age: 26, marketValue: 45000000, wage: 120000, contractExpires: "2027-06-30", status: "Injured", appearances: 10, goals: 0, assists: 1, averageRating: "7.2" },
      { name: "Alejandro Garnacho", position: "FWD", jerseyNumber: 17, nationality: "Argentina", age: 19, marketValue: 40000000, wage: 50000, contractExpires: "2028-06-30", status: "Fit", appearances: 20, goals: 7, assists: 3, averageRating: "7.1" },
      { name: "Kobbie Mainoo", position: "MID", jerseyNumber: 37, nationality: "England", age: 18, marketValue: 30000000, wage: 20000, contractExpires: "2027-06-30", status: "Fit", appearances: 15, goals: 2, assists: 2, averageRating: "7.4" },
      { name: "Diogo Dalot", position: "DEF", jerseyNumber: 20, nationality: "Portugal", age: 24, marketValue: 35000000, wage: 85000, contractExpires: "2028-06-30", status: "Fit", appearances: 26, goals: 1, assists: 3, averageRating: "7.0" },
      { name: "Harry Maguire", position: "DEF", jerseyNumber: 5, nationality: "England", age: 31, marketValue: 20000000, wage: 190000, contractExpires: "2025-06-30", status: "Fit", appearances: 18, goals: 1, assists: 1, averageRating: "6.9" },
      { name: "Casemiro", position: "MID", jerseyNumber: 18, nationality: "Brazil", age: 32, marketValue: 30000000, wage: 350000, contractExpires: "2026-06-30", status: "Suspended", appearances: 20, goals: 4, assists: 2, averageRating: "6.9" },
      { name: "Rasmus Hojlund", position: "FWD", jerseyNumber: 11, nationality: "Denmark", age: 21, marketValue: 65000000, wage: 85000, contractExpires: "2028-06-30", status: "Fit", appearances: 22, goals: 10, assists: 2, averageRating: "7.2" },
    ];
    for (const p of players) await storage.createPlayer(p);

    // Seed Matches
    const matches = [
      { opponent: "Manchester City", isHome: true, date: new Date("2025-03-05"), competition: "Premier League", status: "Upcoming", scoreFor: null, scoreAgainst: null },
      { opponent: "Liverpool", isHome: false, date: new Date("2025-02-28"), competition: "Premier League", status: "Upcoming", scoreFor: null, scoreAgainst: null },
      { opponent: "Arsenal", isHome: true, date: new Date("2025-02-15"), competition: "Premier League", status: "Played", scoreFor: 2, scoreAgainst: 1, possession: 45, xgFor: "1.8", xgAgainst: "1.2" },
      { opponent: "Aston Villa", isHome: false, date: new Date("2025-02-08"), competition: "Premier League", status: "Played", scoreFor: 3, scoreAgainst: 2, possession: 52, xgFor: "2.1", xgAgainst: "1.5" },
    ];
    for (const m of matches) await storage.createMatch(m);

    // Seed Scouting Reports
    const reports = [
      { playerName: "Antonio Silva", currentClub: "Benfica", age: 20, position: "DEF", rating: 82, potential: 89, marketValue: 45000000, scoutName: "John Doe", status: "Shortlisted", notes: "Excellent ball-playing defender with great anticipation." },
      { playerName: "Joao Neves", currentClub: "Benfica", age: 19, position: "MID", rating: 79, potential: 91, marketValue: 50000000, scoutName: "Jane Smith", status: "Monitoring", notes: "High work rate, great passing range, future star." },
      { playerName: "Victor Osimhen", currentClub: "Napoli", age: 25, position: "FWD", rating: 88, potential: 90, marketValue: 110000000, scoutName: "John Doe", status: "Offered", notes: "World class striker, expensive but guarantees goals." },
    ];
    for (const r of reports) await storage.createScoutReport(r);

    // Seed Finances
    const finances = [
      { category: "Ticket Sales", amount: 2500000, type: "Income", description: "Matchday revenue vs Arsenal" },
      { category: "Sponsorship", amount: 15000000, type: "Income", description: "Quarterly kit sponsor payment" },
      { category: "Salaries", amount: -4500000, type: "Expense", description: "Monthly player wages" },
      { category: "Operations", amount: -500000, type: "Expense", description: "Stadium maintenance" },
    ];
    for (const f of finances) await storage.createFinanceRecord(f);
  }
}

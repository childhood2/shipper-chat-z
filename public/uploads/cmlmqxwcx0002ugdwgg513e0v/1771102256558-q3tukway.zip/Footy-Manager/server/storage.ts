import { db } from "./db";
import {
  players, matches, scoutingReports, finances,
  type InsertPlayer, type UpdatePlayerRequest, type Player,
  type InsertMatch, type UpdateMatchRequest, type Match,
  type InsertScoutReport, type ScoutReport,
  type InsertFinanceRecord, type FinanceRecord
} from "@shared/schema";
import { eq, desc, asc } from "drizzle-orm";

export interface IStorage {
  // Players
  getPlayers(): Promise<Player[]>;
  getPlayer(id: number): Promise<Player | undefined>;
  createPlayer(player: InsertPlayer): Promise<Player>;
  updatePlayer(id: number, updates: UpdatePlayerRequest): Promise<Player>;
  deletePlayer(id: number): Promise<void>;

  // Matches
  getMatches(): Promise<Match[]>;
  getMatch(id: number): Promise<Match | undefined>;
  createMatch(match: InsertMatch): Promise<Match>;
  updateMatch(id: number, updates: UpdateMatchRequest): Promise<Match>;

  // Scouting
  getScoutReports(): Promise<ScoutReport[]>;
  createScoutReport(report: InsertScoutReport): Promise<ScoutReport>;

  // Finances
  getFinances(): Promise<FinanceRecord[]>;
  createFinanceRecord(record: InsertFinanceRecord): Promise<FinanceRecord>;
}

export class DatabaseStorage implements IStorage {
  // Players
  async getPlayers(): Promise<Player[]> {
    return await db.select().from(players).orderBy(desc(players.marketValue));
  }

  async getPlayer(id: number): Promise<Player | undefined> {
    const [player] = await db.select().from(players).where(eq(players.id, id));
    return player;
  }

  async createPlayer(insertPlayer: InsertPlayer): Promise<Player> {
    const [player] = await db.insert(players).values(insertPlayer).returning();
    return player;
  }

  async updatePlayer(id: number, updates: UpdatePlayerRequest): Promise<Player> {
    const [updated] = await db.update(players)
      .set(updates)
      .where(eq(players.id, id))
      .returning();
    return updated;
  }

  async deletePlayer(id: number): Promise<void> {
    await db.delete(players).where(eq(players.id, id));
  }

  // Matches
  async getMatches(): Promise<Match[]> {
    return await db.select().from(matches).orderBy(asc(matches.date));
  }

  async getMatch(id: number): Promise<Match | undefined> {
    const [match] = await db.select().from(matches).where(eq(matches.id, id));
    return match;
  }

  async createMatch(insertMatch: InsertMatch): Promise<Match> {
    const [match] = await db.insert(matches).values(insertMatch).returning();
    return match;
  }

  async updateMatch(id: number, updates: UpdateMatchRequest): Promise<Match> {
    const [updated] = await db.update(matches)
      .set(updates)
      .where(eq(matches.id, id))
      .returning();
    return updated;
  }

  // Scouting
  async getScoutReports(): Promise<ScoutReport[]> {
    return await db.select().from(scoutingReports).orderBy(desc(scoutingReports.rating));
  }

  async createScoutReport(insertReport: InsertScoutReport): Promise<ScoutReport> {
    const [report] = await db.insert(scoutingReports).values(insertReport).returning();
    return report;
  }

  // Finances
  async getFinances(): Promise<FinanceRecord[]> {
    return await db.select().from(finances).orderBy(desc(finances.date));
  }

  async createFinanceRecord(insertRecord: InsertFinanceRecord): Promise<FinanceRecord> {
    const [record] = await db.insert(finances).values(insertRecord).returning();
    return record;
  }
}

export const storage = new DatabaseStorage();
